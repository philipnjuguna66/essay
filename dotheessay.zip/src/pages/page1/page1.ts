import { Component } from '@angular/core';
import { SettingService } from '../../app/services/settings.service'; 
import { NavController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
import 'rxjs/add/operator/map';
import {Http, Headers} from '@angular/http';

@Component({
  selector: 'page-page1',
  templateUrl: 'page1.html'
})
export class Page1 {
 items : any;
  constructor(public navCtrl: NavController, private http: Http,private settingService: SettingService , private alert: AlertController) {
   
  }
  ngOnInit()
  {
    this.getOrders();
  }
  
  getOrders(){
    
   var headers = new Headers();
   let link ="https://dotheessay.com/essay/public/api/getorders";  
   let da={};
   
    headers.append('Content-Type', 'application/x-www-form-urlencoded');

      return new Promise(resolve => {
        
            this.http.get(link,{headers: headers}).map(res=>res.json())
            .subscribe(response => {
            this.items=response.data;
            console.log(response);            
        },
        err=>{
            let alert= this.alert.create({
              title: "Warning",
              subTitle: "Please check network connection",
              buttons: ['OK']
             });
          alert.present();   

      }); 
            
   });
  }
}
 