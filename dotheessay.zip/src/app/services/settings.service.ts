import { Injectable } from '@angular/core';
import {Http, Headers} from '@angular/http';
import 'rxjs/add/operator/map';

/*
  Generated class for the MyService provider.

  See https://angular.io/docs/ts/latest/guide/dependency-injection.html
  for more info o n providers and Angular 2 DI.
*/
@Injectable()

export class SettingService {
	http:any;
	baseUrl: String;

	constructor(http: Http) {
		this.http=http;
		this.baseUrl="http://127.0.0.1:81/dotheessayapi/public/api";
		console.log('Hello MyService Provider');
	}

	getOrders(){
    
   var headers = new Headers();
   let link ="http://127.0.0.1:81/dotheessayapi/public/api/getorders";  
   let da={};
   
    headers.append('Content-Type', 'application/x-www-form-urlencoded');

        
            this.http.get(link,{headers: headers}).map(res=>res.json())
            
       
  }
	

}
